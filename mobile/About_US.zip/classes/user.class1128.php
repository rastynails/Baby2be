<?php
class user
{
	 private $username		=	"";
	 private $password		=	"";
	 private $timestamp		=	"";
	 private $email			=	"";
	 private $profile_id	=	"";
	 private $randompass	=	"";
	 
/************************************************************************
	 
  Accepts the username, password and timestamp and return the profile id
	 
*************************************************************************/
	 
	 public function usrSignUp($kv)
	 {
	 	$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$profile_tbl			=	$essence->tblPrefix().'profile';
		$profile_tbl_extended	=	$essence->tblPrefix().'profile_extended';
		
		$keyvalue = array('join_stamp' => time());
		foreach ($kv as $key => $value)
		{
			$keyvalue[$key] = stripcslashes($value);
		}
		//print_r($keyvalue);
		//exit;
		if(count($keyvalue))
		{
			$profile_id	=	$db->InsertRow($profile_tbl,$keyvalue);
			$newkv		= 	array('profile_id' => $profile_id);
			$db->InsertRow($profile_tbl_extended,$newkv);
			echo '{"Profile_Id":"'.$profile_id.'","Profile_Pic":"","Notifications" : "0"}';
		}
	 }
	  /** ------------------------------------------------------------------ */
	 public function usrSignIn($un,$ps,$ts)
	  {
	  		$username	=	$un;
			$password	=	$ps;
			$timestamp	=	$ts;
			$this->authenticate($username,$password,$timestamp);
	  }
	   /** ------------------------------------------------------------------ */
	 private function authenticate($username,$password,$timestamp)
	 {
	 		$essence	=	new Essentials();
			$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			
			if (!$db->Error())
			{
				$profile_tbl			=	$essence->tblPrefix().'profile';
				$profile_online			=	$essence->tblPrefix().'profile_online';
				
				if ($db->Query("SELECT * from $profile_tbl where username='$username' and password='$password'"))
				
				{
					if($db->RowCount())
					{
						$row				=	$db->Row();
						$profile_id			=	$row->profile_id;
						$thumbnail			=	$this->getThumbImage($profile_id);
						$Notifications		=	$this->getNotifications($profile_id);
						$sex				=	$row->sex;
						//$query	=	"INSERT INTO `$profile_online` VALUES('$profile_id','$hash','$time','0.0.0.0','mobile')";
						//$a		=	$db1->Query($query);
						
						echo '{"profile_id":"'.$profile_id.'","Profile_Pic":"'.$thumbnail.'","Notifications" : "'.$Notifications.'","sex" : "'.$sex.'"}';

					}
					else
					{
						echo '{"profile_id":"NULL","Message":"No such Username-Password Combination"}';

					}
				}
				else
				{
					echo '{"profile_id":"NULL","Message":"Failed Executing Query, Try again later"}';

				}
			$essence	=	new Essentials();
			$db1		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			
				//$time				=	'"'.time().'"';
				//$hash				=	'"'.md5('anand').'"';
				$time				=	time();
				$hash				=	md5(rand(0,10000));
				$ip					=	'"0.0.0.0"';
				$agent				=	'"mobile"';
				//$r					=	array('profile_id' => $profile_id, 'hash' => $hash,'expiration_time'=>$time,'ip'=>$ip,'agent'=>$agent);		
				//$ins				=	$db1->InsertRow($profile_online,$r);
				
				$test=mysql_query("SELECT * from $profile_tbl where username='$username' and password='$password'");
				$row=mysql_fetch_array($test);
				$profile_id=$row['profile_id'];
				
			    $query				=	"INSERT INTO `$profile_online` VALUES('$profile_id','$hash','$time','0.0.0.0','mobile')";
				$a					=	$db1->Query($query);
				//print_r($a);
						
			}
			else
			{
				echo '{"profile_id":"NULL","Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
	 } 
	 /** ------------------------------------------------------------------ */
	 public function getThumbImage($pid)
	 {
	 	$essence			=	new Essentials();
		$profile_pic_tbl	=	$essence->tblPrefix().'profile_photo';
		$sql				=	"SELECT `photo_id`, `index` from `$profile_pic_tbl` where `profile_id`=$pid and `number`=0";
		$db1 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		if($db1->Query($sql))
		{
			if($db1->RowCount())
			{
				$row1		=	$db1->Row();
				$photo_id	=	$row1->photo_id;
				$index		=	$row1->index;
				return 	'\/$userfiles'."\/thumb_$pid"."_"."$photo_id"."_"."$index".".jpg";
			}
			else
			{
				return NULL;
			}
			$db1->kill();
		}
	 }
	 /** ------------------------------------------------------------------ */
	  public function getNotifications($pid)
	 {
	 	 	$essence			        =	new Essentials();
		$mailbox_conversation_tbl	=	$essence->tblPrefix().'mailbox_conversation';
		$mailbox_message_tbl		=	$essence->tblPrefix().'mailbox_message';
		$im_message_tbl             =	$essence->tblPrefix().'im_message';
		$photo						=	$essence->tblPrefix().'profile_photo';
		
		$db1 						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db 						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		
		
				  $sql1="SELECT COUNT(DISTINCT `c`.`conversation_id`) as count1 FROM `skadate_mailbox_conversation` AS `c` LEFT JOIN `skadate_mailbox_message` AS `m` ON (`c`.`conversation_id` = `m`.`conversation_id`) WHERE (`initiator_id`=$pid OR `interlocutor_id`=$pid) AND (`bm_deleted` IN(0,2) AND `initiator_id`=$pid OR `bm_deleted` IN(0,1) AND `interlocutor_id`=$pid) AND (`bm_read` IN(0,2) AND `initiator_id`=$pid OR `bm_read` IN(0,1) AND `interlocutor_id`=$pid) AND `m`.`status`='a' AND `m`.`recipient_id`=$pid";
 
				$sql ="SELECT im_message_id,sender_id as im_sender_id,recipient_id as im_recipient_id,text as im_text,Profile_Pic as im_Profile_Pic,username as im_username,FROM_UNIXTIME(timestamp,'%T') as im_time_stamp 
					   FROM (SELECT * FROM skadate_im_message JOIN skadate_profile where skadate_im_message.recipient_id =$pid AND skadate_im_message.read =0 AND skadate_profile.profile_id=skadate_im_message.sender_id)as X 
					   LEFT JOIN
					   (SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic FROM skadate_profile_photo where skadate_profile_photo.number=0)as Y 
				ON X.sender_id=Y.profile_id";
		
		$db->Query($sql);
		$row	=	$db->Row();
		$cnt1=$db->RowCount()?$db->RowCount():0;
		
		$db1->Query($sql1);
		$row1	=	$db1->Row();
		$cnt2	=	$row1->count1;
			
		  $cnt=$cnt1+$cnt2;
		if($db->Query($sql) || $db1->Query($sql1))
		{
			return $cnt;
		}
		else
		{
				return 0;
		}
		
	 }
	  /** ------------------------------------------------------------------ */
	  public function getNotificationCount($pid)
	  {
	  	$essence			        =	new Essentials();
		$mailbox_conversation_tbl	=	$essence->tblPrefix().'mailbox_conversation';
		$mailbox_message_tbl		=	$essence->tblPrefix().'mailbox_message';
		$im_message_tbl             =	$essence->tblPrefix().'im_message';
		$photo						=	$essence->tblPrefix().'profile_photo';
		
		$db1 						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db 						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		
			
		/* $sql1="SELECT message_id,sender_id,recipient_id,text,Profile_Pic,username,FROM_UNIXTIME(time_stamp,'%T') as time_stamp 
		  		 FROM
				 (SELECT * FROM 
				 (SELECT `skadate_mailbox_message`.message_id,`skadate_mailbox_message`.conversation_id, `skadate_mailbox_message`.time_stamp,`skadate_mailbox_message`.sender_id,`skadate_mailbox_message`.recipient_id, `skadate_mailbox_message`.text, `skadate_mailbox_conversation`.initiator_id, `skadate_mailbox_conversation`.interlocutor_id,`skadate_mailbox_conversation`.subject, 'mailbox' as type,'mailbox' FROM skadate_mailbox_conversation 
				 JOIN 
				 skadate_mailbox_message ON skadate_mailbox_conversation.conversation_id=skadate_mailbox_message.conversation_id AND skadate_mailbox_conversation.interlocutor_id=$pid AND (skadate_mailbox_conversation.bm_read=1 OR skadate_mailbox_conversation.bm_read=2))as X
				 JOIN
				 (SELECT * FROM skadate_profile )as Y ON X.sender_id=Y.profile_id) as A
				 LEFT JOIN
				 (SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic 
				 FROM skadate_profile_photo where skadate_profile_photo.number=0)as B 
				 ON 
 				 A.profile_id=B.profile_id";*/
				 
				  $sql1="SELECT * FROM (SELECT * FROM (SELECT DISTINCT `c`.`conversation_id` as c_id,`c`.*,`m`.`conversation_id` as conv_id,`m`.`status`,`m`.`sender_id`,`m`.`recipient_id`,`m`.`text`,FROM_UNIXTIME(`m`.`time_stamp`,'%T') as time_stamp  FROM `skadate_mailbox_conversation` AS `c` LEFT JOIN `skadate_mailbox_message` AS `m` ON (`c`.`conversation_id` = `m`.`conversation_id`) WHERE (`initiator_id`=$pid OR `interlocutor_id`=$pid) AND (`bm_deleted` IN(0,2) AND `initiator_id`=$pid OR `bm_deleted` IN(0,1) AND `interlocutor_id`=$pid) AND (`bm_read` IN(0,2) AND `initiator_id`=$pid OR `bm_read` IN(0,1) AND `interlocutor_id`=$pid) AND `m`.`status`='a' AND `m`.`recipient_id`=$pid) as A
LEFT JOIN 
(SELECT profile_id,username,sex as msg_sex FROM skadate_profile) as B ON  A.sender_id=B.profile_id) as X
 LEFT JOIN 
(SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic 
				 FROM skadate_profile_photo where skadate_profile_photo.number=0)as Y 
				 ON 
 				 X.profile_id=Y.profile_id";
                 
				$sql ="SELECT im_message_id,sender_id as im_sender_id,recipient_id as im_recipient_id,text as im_text,Profile_Pic as im_Profile_Pic,username as im_username, sex as im_sex, FROM_UNIXTIME(timestamp,'%T') as im_time_stamp 
					   FROM (SELECT * FROM skadate_im_message JOIN skadate_profile where skadate_im_message.recipient_id =$pid AND skadate_im_message.read =0 AND skadate_profile.profile_id=skadate_im_message.sender_id)as X 
					   LEFT JOIN
					   (SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic FROM skadate_profile_photo where skadate_profile_photo.number=0)as Y 
				ON X.sender_id=Y.profile_id";
		
		$db->Query($sql);
		$row	=	$db->Row();
		$db1->Query($sql1);
		$row1	=	$db1->Row();
		$cnt1=$db->RowCount()?$db->RowCount():0;
		$cnt2=$db1->RowCount()?$db1->RowCount():0;
		 $cnt=$cnt1+$cnt2;
		 
			
		  $cnt=$cnt1+$cnt2;
			    /*$sql1="SELECT COUNT(DISTINCT `c`.`conversation_id`) as count1 FROM `skadate_mailbox_conversation` AS `c` LEFT JOIN `skadate_mailbox_message` AS `m` ON (`c`.`conversation_id` = `m`.`conversation_id`) WHERE (`initiator_id`=$pid OR `interlocutor_id`=$pid) AND (`bm_deleted` IN(0,2) AND `initiator_id`=$pid OR `bm_deleted` IN(0,1) AND `interlocutor_id`=$pid) AND (`bm_read` IN(0,2) AND `initiator_id`=$pid OR `bm_read` IN(0,1) AND `interlocutor_id`=$pid) AND `m`.`status`='a' AND `m`.`recipient_id`=$pid";
 
				$sql ="SELECT im_message_id,sender_id as im_sender_id,recipient_id as im_recipient_id,text as im_text,Profile_Pic as im_Profile_Pic,username as im_username,FROM_UNIXTIME(timestamp,'%T') as im_time_stamp 
					   FROM (SELECT * FROM skadate_im_message JOIN skadate_profile where skadate_im_message.recipient_id =$pid AND skadate_im_message.read =0 AND skadate_profile.profile_id=skadate_im_message.sender_id)as X 
					   LEFT JOIN
					   (SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic FROM skadate_profile_photo where skadate_profile_photo.number=0)as Y 
				ON X.sender_id=Y.profile_id";
		
		$db->Query($sql);
		$row	=	$db->Row();
		$cnt1=$db->RowCount()?$db->RowCount():0;
		
		$db1->Query($sql1);
		$row1	=	$db1->Row();
		$cnt2	=	$row1->count1;
			
		  $cnt=$cnt1+$cnt2;*/
		if($db->Query($sql) || $db1->Query($sql1))
		{
			//echo  $cnt;
			echo '{"count": "'.$cnt.'"}';
		}
		else
		{
				echo '{"count":"0","Message":"No Notification"}';
		}
	  }
	 /** ------------------------------------------------------------------ */
	public function Notifications($pid)
	 {   
	 	$essence			        =	new Essentials();
		$mailbox_conversation_tbl	=	$essence->tblPrefix().'mailbox_conversation';
		$mailbox_message_tbl		=	$essence->tblPrefix().'mailbox_message';
		$im_message_tbl             =	$essence->tblPrefix().'im_message';
		$photo						=	$essence->tblPrefix().'profile_photo';
		$rslt1						=	"SELECT COUNT(conversation_id) AS cnt FROM $mailbox_conversation_tbl where interlocutor_id=$pid AND bm_read=1";
		$db1 						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db 						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db2						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db3						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		$db1->Query($rslt1);
		$row1		=	$db1->Row();
		$cnt1       =   $row1->cnt;
		
	
		 $rslt2       		 = "SELECT COUNT(im_message_id) AS cnt FROM $im_message_tbl  where recipient_id=$pid AND $im_message_tbl.read=0";
		$db2				 = 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
	
		$db2->Query($rslt2);
		
		$row2		=	$db2->Row();
		$cnt2   	=	$row2->cnt;
			
		   /*  $sql1="SELECT message_id,sender_id,recipient_id,text,Profile_Pic,username,sex as msg_sex, FROM_UNIXTIME(time_stamp,'%T') as time_stamp 
		  		 FROM
				 (SELECT * FROM 
				 (SELECT `skadate_mailbox_message`.message_id,`skadate_mailbox_message`.conversation_id, `skadate_mailbox_message`.time_stamp,`skadate_mailbox_message`.sender_id,`skadate_mailbox_message`.recipient_id, `skadate_mailbox_message`.text, `skadate_mailbox_conversation`.initiator_id, `skadate_mailbox_conversation`.interlocutor_id,`skadate_mailbox_conversation`.subject, 'mailbox' as type,'mailbox' FROM skadate_mailbox_conversation 
				 JOIN 
				 skadate_mailbox_message ON skadate_mailbox_conversation.conversation_id=skadate_mailbox_message.conversation_id AND skadate_mailbox_message.recipient_id=$pid AND (skadate_mailbox_conversation.bm_read=1 OR skadate_mailbox_conversation.bm_read=2))as X
				 JOIN
				 (SELECT * FROM skadate_profile )as Y ON X.sender_id=Y.profile_id) as A
				 LEFT JOIN
				 (SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic 
				 FROM skadate_profile_photo where skadate_profile_photo.number=0)as B 
				 ON 
 				 A.profile_id=B.profile_id";*/
				 
				  $sql1="SELECT * FROM (SELECT * FROM (SELECT DISTINCT `c`.`conversation_id` as c_id,`c`.*,`m`.`conversation_id` as conv_id,`m`.`status`,`m`.`sender_id`,`m`.`recipient_id`,`m`.`text`,FROM_UNIXTIME(`m`.`time_stamp`,'%T') as time_stamp  FROM `skadate_mailbox_conversation` AS `c` LEFT JOIN `skadate_mailbox_message` AS `m` ON (`c`.`conversation_id` = `m`.`conversation_id`) WHERE (`initiator_id`=$pid OR `interlocutor_id`=$pid) AND (`bm_deleted` IN(0,2) AND `initiator_id`=$pid OR `bm_deleted` IN(0,1) AND `interlocutor_id`=$pid) AND (`bm_read` IN(0,2) AND `initiator_id`=$pid OR `bm_read` IN(0,1) AND `interlocutor_id`=$pid) AND `m`.`status`='a' AND `m`.`recipient_id`=$pid) as A
LEFT JOIN 
(SELECT profile_id,username,sex as msg_sex FROM skadate_profile) as B ON  A.sender_id=B.profile_id) as X
 LEFT JOIN 
(SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic 
				 FROM skadate_profile_photo where skadate_profile_photo.number=0)as Y 
				 ON 
 				 X.profile_id=Y.profile_id";
                 
				$sql ="SELECT im_message_id,sender_id as im_sender_id,recipient_id as im_recipient_id,text as im_text,Profile_Pic as im_Profile_Pic,username as im_username, sex as im_sex, FROM_UNIXTIME(timestamp,'%T') as im_time_stamp 
					   FROM (SELECT * FROM skadate_im_message JOIN skadate_profile where skadate_im_message.recipient_id =$pid AND skadate_im_message.read =0 AND skadate_profile.profile_id=skadate_im_message.sender_id)as X 
					   LEFT JOIN
					   (SELECT *,CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic FROM skadate_profile_photo where skadate_profile_photo.number=0)as Y 
				ON X.sender_id=Y.profile_id";
		
		$db->Query($sql);
		$row	=	$db->Row();
		$db1->Query($sql1);
		$row1	=	$db1->Row();
		$cnt1=$db->RowCount()?$db->RowCount():0;
		$cnt2=$db1->RowCount()?$db1->RowCount():0;
		 $cnt=$cnt1+$cnt2;
		 
			
		  $cnt=$cnt1+$cnt2;
		
				if($db->RowCount() && $db1->RowCount())
				{															
					 $profile 		= 	'{"Notifications": '.$cnt.',"MailCount" : '.$cnt2.',"IMCount" : '.$cnt1.',"result": ['.$db->GetJSON().$db1->GetJSON().']}';
					 echo $profile	= 	str_replace("},]}", "}]}", $profile);
					 $result="UPDATE `skadate_im_message`  SET `read`=1 where `recipient_id`=$pid AND `read`=0";
					 $db2->Query($result);
					 
				}  
				else if($db->RowCount()>0 && $db1->RowCount()<1)
				{														
					 $profile 		= 	'{"Notifications": '.$cnt.',"MailCount" : '.$cnt2.',"IMCount" : '.$cnt1.',"result": ['.$db->GetJSON().']}';
					 echo $profile	= 	str_replace("},]}", "}]}", $profile);
					 $result="UPDATE `skadate_im_message`  SET `read`=1 where `recipient_id`=$pid AND `read`=0";
					 $db3->Query($result);
				} 
				else if($db->RowCount()<1 && $db1->RowCount()>0)
				{														
					 $profile 		= 	'{"Notifications": '.$cnt.',"MailCount" : '.$cnt2.',"IMCount" : '.$cnt1.',"result": ['.$db1->GetJSON().']}';
					 echo $profile	= 	str_replace("},]}", "}]}", $profile);
				}   
			else
			{
				echo '{"Notifications":"0"}';
			}
			return $cnt;
			
	 }
	 /** ------------------------------------------------------------------ */
	 public function resetpassword($fnemail)
	 {
	 		//$profile_id		=	$fnprofile_id;
			$email			=	$fnemail;
			$essence		=	new Essentials();
			$db 			= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			if (!$db->Error())
			{
				$profile_tbl	=	$essence->tblPrefix().'profile';
				if ($db->Query("SELECT * from $profile_tbl where email='$email'"))
				{
					if($db->RowCount())
					{
						 $args 	= 	array(  'length' => $essence->getpasslen(),
											'alpha_upper_include'	=>	TRUE,
											'alpha_lower_include'	=>	TRUE,						
											'number_include'		=>	TRUE,
											'symbol_include'		=>	FALSE);
						 $pwd 	= 	new password_generator( $args );
						 $orgipass	=	$pwd->get_password();
						 $hashpass	=	sha1($essence->getHashSalt() . $orgipass); 
									 
						 $mailer = new Mailer ();
						 $mailer->addr = $email;
 						 //$mailer->to = 'John';
						 $mailer->subject = 'Password reset!';
						 $mailer->from_addr = $essence->getSiteEmail();
						 $mailer->tpl_containers = array ('{%SIGNATURE%}'=>'Site Admin', '{%PASSWORD%}'=> $orgipass);
						 $mailer->ProcessTemplate ( '../templates/msg.txt' );
						 $mailer->SendMail ();
					 	
						 $sql	=	"UPDATE `$profile_tbl` SET `password`='".$hashpass."' where `email`='".$email."'";							 
						 $db->Query($sql);
						 echo '{"Message":"Email sent to given email address"}';
						 					 
					}
					else
					{
						echo '{"Token":"NULL","Message":"Email address provided does not match any record"}';
					}
				}
				else
				{
					echo '{"Token":"NULL","Message":"Failed Executing Query, Try again later"}';
					$db->Kill();
				}
			}
			else
			{
				echo '{"Token":"NULL","Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
	 }
	 /** ------------------------------------------------------------------ */
	 public function checkAvail($uname)
	 {
	 	$essence	=	new Essentials();
		$salt		=	$essence->getHashSalt();

	
			$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			if (!$db->Error())
			{
				$profile_tbl	=	$essence->tblPrefix().'profile';
				if ($db->Query("SELECT * from $profile_tbl where username='$uname'"))
				{
					if($db->RowCount())
					{
						echo '{"Message":"Username Already Taken",'.'"Salt":"'.$salt.'"}';
				      	
					}
					else
					{
						echo '{"Message":"Username Available",'.'"Salt":"'.$salt.'"}';
						
					}
				}
				else
				{
					echo '{"Message":"Failed Executing Query, Try again later"}';
					$db->Kill();
				}
			}
			else
			{
				echo '{"Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
	 }
	 /** ------------------------------------------------------------------ */
	 public function getUsrDetail($id)
	 {
	 	$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		//$db1		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		if (!$db->Error())
			{
				$profile_tbl			=	$essence->tblPrefix().'profile';
				$profile_tbl_extended	=	$essence->tblPrefix().'profile_extended';
				$profile_view_history	=	$essence->tblPrefix().'skadate_profile_view_history';
				$sql	=	"	SELECT *, year(CURRENT_TIMESTAMP)-year(birthdate) as DOB  FROM  $profile_tbl ,  $profile_tbl_extended
 								WHERE  $profile_tbl.profile_id =$id 
								AND  $profile_tbl_extended.profile_id =$id";
								
				//$time	=	time();				
				if ($db->Query($sql))
				{
					if($db->RowCount())
					{	
							//$sql1="INSERT INTO $profile_view_history VALUES('','$id', '$vid', '$time')";
							//$db1->Query($sql1);							
							$profile1	=	 $db->GetJSON();
							
							$url		=	$this->getThumbImage($id);
							if($url	==	"")
								$url	=	"NULL";
							$profile1	=	str_replace('}',',"Profile_Image":"'.$url.'"}',$profile1);
							$profile1	= 	str_replace("},", "}", $profile1);
							echo $profile1;
					}
					else
					{
						echo '{"Message":"Incorrect ID"}';
					}	
				
				}
			}
			else
			{
				echo '{"Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
	 }
	  /** ------------------------------------------------------------------ */
	  public function getUsrDetails($id,$vid)
	 {
	 	$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		if (!$db->Error())
			{
				$profile_tbl			=	$essence->tblPrefix().'profile';
				$profile_tbl_extended		=	$essence->tblPrefix().'profile_extended';
				$profile_view_history		=	$essence->tblPrefix().'profile_view_history';
				$sql	=	"	SELECT *, year(CURRENT_TIMESTAMP)-year(birthdate) as DOB  FROM  $profile_tbl ,  $profile_tbl_extended
 								WHERE  $profile_tbl.profile_id =$id 
								AND  $profile_tbl_extended.profile_id =$id";
								
				$time	=	time();				
				if ($db->Query($sql))
				{
					if($db->RowCount())
					{	
							$sql1="INSERT INTO $profile_view_history VALUES('',$id, $vid, $time)";
							$db1->Query($sql1);							
							$profile1	=	 $db->GetJSON();
							
							$url		=	$this->getThumbImage($id);
							if($url	==	"")
								$url	=	"NULL";
							$profile1	=	str_replace('}',',"Profile_Image":"'.$url.'"}',$profile1);
							$profile1	= 	str_replace("},", "}", $profile1);
							echo $profile1;
					}
					else
					{
						echo '{"Message":"Incorrect ID"}';
					}	
				
				}
			}
			else
			{
				echo '{"Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
	 }
	  /** ------------------------------------------------------------------ */
	  public function UsrDetail($id,$vid)
	 {
	 	$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		if (!$db->Error())
			{
				$profile_tbl			=	$essence->tblPrefix().'profile';
				$profile_tbl_extended		=	$essence->tblPrefix().'profile_extended';
				$viewtable			=	$essence->tblPrefix().'profile_view_history';
				
				$sql	=	"SELECT *, year(CURRENT_TIMESTAMP)-year(birthdate) as DOB  FROM  $profile_tbl ,  $profile_tbl_extended
 								WHERE  $profile_tbl.profile_id =$id 
								AND  $profile_tbl_extended.profile_id =$id";
				if ($db->Query($sql))
				{
					if($db->RowCount())
					{	
							if($vid)
							{
								$kv	=	array('profile_id'=>$vid,'viewed_id'=>$id,'time_stamp'=>time());
								//print_r($kv);
								$abc	=	$db1->InsertRow($viewtable,$kv);
							}
							$profile1	=	 $db->GetJSON();
							
							$url		=	$this->getThumbImage($id);
							if($url	==	"")
								$url	=	"NULL";
							$profile1	=	str_replace('}',',"Profile_Image":"'.$url.'"}',$profile1);
							$profile1	= 	str_replace("},", "}", $profile1);
							echo $profile1;
					}
					else
					{
						echo '{"Message":"Incorrect ID"}';
					}	
				
				}
			}
			else
			{
				echo '{"Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
	 }
	 /** ------------------------------------------------------------------ */
 	 public function getConvMsg($id)
	 {
	 	$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		if (!$db->Error())
			{
				$mail_conv_tbl			=	$essence->tblPrefix().'mailbox_conversation';
				$mail_msg_tbl			=	$essence->tblPrefix().'mailbox_message';
				$sql	=	"
								SELECT * FROM  `$mail_conv_tbl` ,  `$mail_msg_tbl`
 								WHERE  `$mail_conv_tbl`.conversation_id =$id 
								AND  `$mail_msg_tbl`.conversation_id =`$mail_conv_tbl`.conversation_id";
				
			
				if ($db->Query($sql))
				{
					if($db->RowCount())
					{	
							
							$profile	=	 $db->GetJSON();
							
							$url		=	$this->getThumbImage($id);
							if($url	==	"")
								$url	=	"NULL";
							$profile	=	str_replace('}',',"Profile_Image":"'.$url.'"}',$profile);
							echo $profile;
					}
					else
					{
						echo '{"Message":"Incorrect ID"}';
					}	
				
				}
			}
			else
			{
				echo '{"Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
	 }
	 /** ------------------------------------------------------------------ */
	 public function userJoin($kv)
	 {
		$essence				=	new Essentials();
		$profile_table			=	$essence->tblPrefix().'profile';	
		$db 					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());	
	 	$profile_id				=	$db->InsertRow('skadate_profile',$kv);
		$newkv					= 	array('profile_id' => $profile_id);
		$profile_table_extend	=	$essence->tblPrefix().'profile_extended';
		$db->InsertRow($profile_table_extend,$newkv);
		echo '{"Profile_Id":"'.$profile_id.'","Profile_Pic":"","Notifications" : "0"}';
	 }
	  
	  /** ------------------------------------------------------------------ */
	 public function BookmarkProfile($pid,$bid)
	 {
		 $essence		=	new Essentials();
		 $bookmark_tbl	=	$essence->tblPrefix().'profile_bookmark_list';		
		 $db 			= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		 if (!$db->Error())
			{
				$newkv	=	array('profile_id' => $pid, 'bookmarked_id' => $bid);		
				$db->InsertRow($bookmark_tbl,$newkv);
				echo '{"Message":"Bookmarked"}';
			}
	 }
	 /** ------------------------------------------------------------------ */
	 public function getNewMembers()
	 {
		 $essence				=	new Essentials();
		 $profile_table			=	$essence->tblPrefix().'profile';	
		 $profile_tbl_online	=	$essence->tblPrefix().'profile_online';
		 $country_tbl			=	$essence->tblPrefix().'location_country';
		 $pic_tbl				=	$essence->tblPrefix().'profile_photo';
		 
		 $db 					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		 if (!$db->Error())
			{
				/*$sql	=	"SELECT main.profile_id,username,sex,custom_location,Country_str_name,hash as OnlineStatus, year(CURRENT_TIMESTAMP)-year(birthdate) as DOB, photo_id, ptbl.index as pindex FROM $profile_table AS `main` LEFT JOIN `$profile_table_online` AS `online` USING( `profile_id` ) LEFT JOIN `$country_tbl` AS `ctbl` ON (main.`country_id`= ctbl.`Country_str_code`) LEFT JOIN ``$pic_tbl`` AS `ptbl` ON(  main.`profile_id` = ptbl.`profile_id` and ptbl.number=0 ) ORDER BY `join_stamp` DESC LIMIT 0 , 10";*/
				$sql	=	"SELECT main.profile_id,username,sex,custom_location,Country_str_name,hash as OnlineStatus, 
year(CURRENT_TIMESTAMP)-year(birthdate) as DOB, photo_id,
CONCAT( '/$','userfiles/thumb_', CAST( ptbl.profile_id AS CHAR ) , '_',
CAST( ptbl.photo_id AS CHAR ) , '_',
CAST( ptbl.index AS CHAR ) , '.jpg' ) as Profile_Pic,

 ptbl.index as pindex FROM $profile_table AS `main`
 LEFT JOIN `$profile_tbl_online` AS `online` USING( `profile_id` ) 
LEFT JOIN `$country_tbl` AS `ctbl` ON (main.`country_id`= `ctbl`.`Country_str_code`) 
LEFT JOIN `$pic_tbl` AS `ptbl` ON( main.`profile_id` = ptbl.`profile_id` and ptbl.number=0 ) 
ORDER BY `join_stamp`
 DESC LIMIT 0 , 10";
				
				
				if($db->Query($sql))
				{
					if($db->RowCount())
					{
						$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
						echo $profile = str_replace("},]", "}]", $profile);
					}
				}
				
			}
		else
			{
			echo '{"count":"0","Message":"No Online Members"}';
			}	
	 }
	 /** ------------------------------------------------------------------ */
	  public function getOnlineMembers()
	 	{
		 $essence				=	new Essentials();
		 $online_table 			=	$essence->tblPrefix().'profile_online';	
		 $profile_table			=	$essence->tblPrefix().'profile';
		 $profile_table_extend	=	$essence->tblPrefix().'location_country';
		 $pic_tbl				=	$essence->tblPrefix().'profile_photo';
		
		 $db 			= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		 if (!$db->Error())
			{
				 $sql	=	"SELECT `skadate_profile`.profile_id, `skadate_profile`.username, `skadate_profile`.sex, skadate_profile.birthdate, skadate_profile.custom_location, 
skadate_profile.country_id, skadate_profile.state_id, skadate_profile.city_id, skadate_location_country.Country_str_name,skadate_profile.has_photo, year(
CURRENT_TIMESTAMP ) - year( birthdate ) AS DOB, CONCAT( '/$', 'userfiles/thumb_', CAST( `skadate_profile_photo`.profile_id AS CHAR ) , '_', CAST( 
`skadate_profile_photo`.photo_id AS CHAR ) , '_', CAST( `skadate_profile_photo`.index AS CHAR ) , '.jpg' ) AS Profile_Pic
FROM skadate_profile JOIN skadate_profile_online ON skadate_profile_online.profile_id= skadate_profile.profile_id join skadate_location_country ON skadate_location_country.Country_str_code = skadate_profile.country_id 
LEFT JOIN `$pic_tbl` ON skadate_profile.profile_id=`$pic_tbl`.profile_id AND `$pic_tbl`.`number` = 0 ORDER BY expiration_time DESC";

			if($db->Query($sql))
				{ 
					if($db->RowCount())
					{
						$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
						echo $profile = str_replace("},]", "}]", $profile);
					}
				}
			}
		else
			{
			echo '{"count":"0","Message":"No Online Members"}';
			}	
		}
	 /** ------------------------------------------------------------------ */
	 public function BookmarkedMembers($pid)
	 {
		 $essence	=	new Essentials();
		 $db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		 $profile_tbl			=	$essence->tblPrefix().'profile';
		 $profile_tbl_extended	=	$essence->tblPrefix().'profile_bookmark_list';
		 $location_table  		=	$essence->tblPrefix().'location_country';
	 	 $profile_state			=	$essence->tblPrefix().'location_state';
		 $pic_tbl				=	$essence->tblPrefix().'profile_photo';
		 
		 if (!$db->Error())
			{
				/*$sql					=	"
				SELECT * ,year(CURRENT_TIMESTAMP)-year(birthdate) as DOB,Country_str_name as Country_str_name, CONCAT( '/$','userfiles/thumb_', CAST( `$pic_tbl`.profile_id AS CHAR ) ,  '_', 
				CAST( `$pic_tbl`.photo_id AS CHAR ) ,  '_', CAST( `$pic_tbl`.index AS CHAR ) ,  '.jpg' ) 
				as Profile_Pic
				FROM `$profile_tbl` ,`$profile_tbl_extended`,`$location_table`,`$pic_tbl`
				WHERE `$profile_tbl`.profile_id =`$profile_tbl_extended`.bookmarked_id AND
				`$profile_tbl_extended`.profile_id =$pid AND
				`$location_table`.Country_str_code=`$profile_tbl`.country_id AND
				`$pic_tbl`.profile_id = `$profile_tbl`.profile_id AND
				`$pic_tbl`.number = 0";*/
				
				 $sql					=	"
				SELECT *
					FROM (
					
					SELECT skadate_profile.profile_id, skadate_profile.username, skadate_profile.birthdate, year(
					CURRENT_TIMESTAMP ) - year( skadate_profile.birthdate ) AS DOB, skadate_profile.sex, Country_str_name AS Country_str_name, skadate_profile.custom_location
					FROM `skadate_profile` , `skadate_profile_bookmark_list` , `skadate_location_country`
					WHERE `skadate_profile`.profile_id = `skadate_profile_bookmark_list`.bookmarked_id
					AND `skadate_profile_bookmark_list`.profile_id =$pid
					AND `skadate_location_country`.Country_str_code = `skadate_profile`.country_id
					) AS X
					LEFT JOIN (
					
					SELECT  skadate_profile_photo.profile_id as prof_id,skadate_profile_photo.photo_id,skadate_profile_photo.index,skadate_profile_photo.number, CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic
					FROM skadate_profile_photo
					WHERE skadate_profile_photo.number =0
					) AS Y ON X.profile_id = Y.prof_id
					";

				if ($db->Query($sql))
				{
					if($db->RowCount())
					{
						$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
						echo $profile = str_replace("},]", "}]", $profile);
					}
					else
					{
						echo '{"count":"0","Message":"Incorrect ID"}';
					}	
				}	
	 		}
	 }


	  /** ------------------------------------------------------------------ */
	public function getFeaturedMembers()
	{
	 $essence				=	new Essentials();
	 $profile_table			=	$essence->tblPrefix().'profile';
	 $profile_table_extend	=	$essence->tblPrefix().'location_country';
	 $profile_state			=	$essence->tblPrefix().'location_state';
	 $pic_tbl				=	$essence->tblPrefix().'profile_photo';
	 
	 $db 			= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
	  if (!$db->Error())
		{
			$sql	=	"
			SELECT *, year(CURRENT_TIMESTAMP)-year(birthdate) as DOB,Country_str_name as Country_str_name, 
Admin1_str_code as State,CONCAT( '/$','userfiles/thumb_', CAST( $pic_tbl.profile_id AS CHAR ) ,  '_', 
CAST( $pic_tbl.photo_id AS CHAR ) ,  '_', CAST( $pic_tbl.index AS CHAR ) ,  '.jpg' ) 
as Profile_Pic  FROM `$profile_table` join (`$profile_table_extend`) 
ON (`$profile_table_extend`.Country_str_code=`$profile_table`.country_id AND `$profile_table`.featured= 'y') 
left join (`$profile_state`) ON (`$profile_state`.Admin1_str_code = `$profile_table`.state_id)
left join (`$pic_tbl`) ON (`$profile_table`.profile_id = `$pic_tbl`.profile_id
AND $pic_tbl.number =0)";

/*
	SELECT *, year(CURRENT_TIMESTAMP)-year(birthdate) as DOB,Country_str_name as Country_str_name, Admin1_str_code as State FROM `$profile_table` join (`$profile_table_extend`) ON (`skadate_location_country`.Country_str_code=`skadate_profile`.country_id AND `skadate_profile`.featured= 'y') left join (`$profile_state`) ON (`profile_state`.Admin1_str_code = `skadate_profile`.state_id)
*/
			if($db->Query($sql))
			{ 
				if($db->RowCount())
				{
					$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
					echo $profile = str_replace("},]", "}]", $profile);
				}
				else
				{
					echo '{"count":"0","Message":"No Members Found"}';
				}	
			}
		}
	}
	/** ------------------------------------------------------------------ */
	 public function ViewPhotos($pid)
	 {	
	  	$essence			=	new Essentials();
		$pic_tbl			=	$essence->tblPrefix().'profile_photo';
		$sql				=	"SELECT `photo_id`, `index` from `$pic_tbl` where `profile_id`=$pid AND `number` > 0";
		$db1 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$str				= 	"";
		if($db1->Query($sql))
		{
			if($db1->RowCount())
			{
				for($i=0;$i<$db1->RowCount();$i++)
				{ 
					$row1		=	$db1->Row();
					$photo_id	=	$row1->photo_id;
					$index		=	$row1->index;
					$str	   .=  '[{';
					$str	   .=  '"Photo"'.':'.'"/$userfiles/'."thumb_$pid"."_"."$photo_id"."_"."$index".".jpg".'"';
					$str	   .=  '}]';
				}
			$str=str_replace("}][{", "},{", $str);
			$profile = '{"count": '.$db1->RowCount().','.'"result": '.$str.'}';
			echo $profile;
			$db1->kill();
			}
			else
			{
				echo '{"count":"0"}';
			}
		 }
		
	 }
	   /** ------------------------------------------------------------------ */
	 public function allContacts()
	 {
		 $essence		=	new Essentials();
		 $profile_table	=	$essence->tblPrefix().'profile';
		 $pic_tbl		=	$essence->tblPrefix().'profile_photo';
		 $db 			= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		  if (!$db->Error())
			{
				$sql	=	"SELECT `$profile_table`.profile_id,`$profile_table`.email, `$profile_table`.username, `$profile_table`.password, `$profile_table`.sex, `$profile_table`.match_sex, `$profile_table`.birthdate, `$profile_table`.headline, `$profile_table`.general_description, `$profile_table`.match_agerange, `$profile_table`.custom_location, `$profile_table`.country_id, `$profile_table`.zip, `$profile_table`.state_id, `$profile_table`.city_id, `$profile_table`.join_stamp, `$profile_table`.activity_stamp, `$profile_table`.membership_type_id, `$profile_table`.affiliate_id, `$profile_table`.email_verified,`$profile_table`.reviewed, `$profile_table`.has_photo, `$profile_table`.has_media,`$profile_table`.featured, `$profile_table`.register_invite_score, `$profile_table`.rate_score,`$profile_table`.rates,`$profile_table`.language_id,`$profile_table`.join_ip,`$profile_table`.neigh_location, `$profile_table`.neigh_location_distance,`$profile_table`.bg_color, `$profile_table`.bg_image, `$profile_table`.bg_image_url, `$profile_table`.bg_image_mode,`$profile_table`.bg_image_status, `$profile_table`.has_music, `$profile_table`.is_private, `$pic_tbl`.photo_id,`$pic_tbl`.index,`$pic_tbl`.status,`$pic_tbl`.number, `$pic_tbl`.description,`$pic_tbl`.publishing_status,`$pic_tbl`.password,`$pic_tbl`.title, `$pic_tbl`.added_stamp,`$pic_tbl`.authed,
CONCAT( '/$','userfiles/thumb_', CAST( $pic_tbl.profile_id AS CHAR ) , '_',
CAST( $pic_tbl.photo_id AS CHAR ) , '_',
CAST( $pic_tbl.index AS CHAR ) , '.jpg' ) as Profile_Pic  

 FROM `$profile_table` LEFT JOIN `$pic_tbl` ON `$profile_table`.profile_id=`$pic_tbl`.profile_id AND `$pic_tbl`.number=0";
			
			if($db->Query($sql))
				{ 
					if($db->RowCount())
					{
						/*$profile	=	 '['.$db->GetJSON().']';
						echo $profile	= 	str_replace("},]", "}]", $profile);*/
						
						$profile	=	 '['.$db->GetJSON().']';
						$profile	= 	str_replace("},]", "}]", $profile);
						$profile = '{"count": '.$db->RowCount().','.'"result": '.$profile.'}';
						echo $profile;
					}
					else
					{
						echo '{"Message":"No Members Found"}';
					}	
				}
			}
	 }
	   /** ------------------------------------------------------------------ */
	 public function ChatMsgSending($id,$msg)
	 {	
	  	$essence				=	new Essentials();
		$profile_pic_tbl		=	$essence->tblPrefix().'chat_message';
		$db						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$time					=	time();
		$sql					=	"INSERT into `$profile_pic_tbl` values('','1','$id', '$msg', '$time', '000000')";
		if($db->Query($sql))
			 {
				echo '{"Message":"Success"}';
			 }
			 else
			 {
				echo '{"Message":"Error"}';
			 }
	  }
	/** ------------------------------------------------------------------ */	   
	public function ChatMsgRetrieving($id)
	{	
		$essence				=	new Essentials();
		$profile_pic_tbl		=	$essence->tblPrefix().'chat_message';
		$db						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$time					=	time();
		$sql					=	"SELECT * from `$profile_pic_tbl` where `profile_id`=$id";
		if($db->Query($sql))
		{
			if($db->RowCount())
			{	
				$profile	=	 '['.$db->GetJSON().']';
				$profile	= 	str_replace("},]", "}]", $profile);
				$profile = '{"count": '.$db->RowCount().','.'"result": '.$profile.'}';
				echo $profile;
			}
			else
			{
				echo '{"count":"0"}';
			}
		}
	}
	 /** ------------------------------------------------------------------ */
	   public function PrivateChatMsgSending($sid,$rid,$msg)
	   {	
	  	$essence				=	new Essentials();
		$im_message_tbl			=	$essence->tblPrefix().'im_message';
		$db						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$time					=	time();
		$msg 					= 	mysql_real_escape_string($msg);
		$im_session_id			=	"";
		$sql					=	"INSERT into `$im_message_tbl` values('','$im_session_id','$sid', '$rid', '$msg', '$time','0','000000')";
		if($db->Query($sql))
			 {
				date_default_timezone_set('Asia/Kolkata');
				echo '{"Message":"Success", "Time": "'.date("H:i:s").'"}';
			 }
			 else
			 {
				echo '{"Message":"Error"}';
			 }
	   }
	   /** ------------------------------------------------------------------ */
	   public function PrivateChatMsgReceiving($sid,$rid)
	    {	
			$essence				=	new Essentials();
			$im_message_tbl			=	$essence->tblPrefix().'im_message';
			$pic_tbl				=	$essence->tblPrefix().'profile_photo';
			$db						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			$time					=	time();
			$im_session_id			=	"";
			$sql					=	"SELECT *,if((sender_id=$sid AND recipient_id=$rid),'sending','receiving') AS chat,FROM_UNIXTIME(timestamp,'%T') AS Time from `$im_message_tbl` where (sender_id=$sid AND recipient_id=$rid) OR (sender_id=$rid AND recipient_id=$sid) ORDER BY timestamp";
			
			if($db->Query($sql))
			{
				if($db->RowCount())
				{	
					$profile	=	 '['.$db->GetJSON().']';
					$profile	= 	str_replace("},]", "}]", $profile);
					$profile = '{"count": '.$db->RowCount().','.'"result": '.$profile.'}';
					echo $profile;
				}
				else
				{
					echo '{"count":"0"}';
				}
			}
	    }

	/** ------------------------------------------------------------------ */
	static function generateMessageHash( $sender, $subject, $message )
	{
		if (!strlen($subject)) // means it is not the first message
		{
			$subject = md5(time());
			$charsonly = preg_replace('~\s+~', '', "$sender-".strtolower(trim($subject).trim($message)));
			$hash = md5($charsonly);
			return $hash;
		}
	}
	 /** ------------------------------------------------------------------ */
	public function ComposeMessage($sender,$recipient,$sub,$msg)
	{	
		$essence				=	new Essentials();
		$profile_pic_tbl		=	$essence->tblPrefix().'mailbox_message';
		$profile_table_extend	=	$essence->tblPrefix().'mailbox_conversation';
		$time					=	time();
		$subject				=	$sub;
		$text 					= 	$msg;
	    $msg 					= 	mysql_real_escape_string($msg);
		$sub 					= 	mysql_real_escape_string($sub);
		$text 					= 	$msg;
		$hash 					= 	self::generateMessageHash( $sender, $subject, $text );
		$db 					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$sql1					=	$db->Query("INSERT into `$profile_table_extend` values('', '$sender','$recipient', '$sub','1', '','1', '$time','yes')");
		$cid					=	mysql_insert_id();
		$sql					=	"INSERT into `$profile_pic_tbl` values('', '$cid','$time', '$sender', '$recipient', '$msg', 'no', 'yes', 'a', '$hash')";
			if($db->Query($sql))
			{
				echo '{"Message":"Success"}';
			}
			else
			{
				echo '{"Message":"Error"}';
			}
	}
	/** ------------------------------------------------------------------ */
	public function DeleteConversationNew($pid,$cid)
	{	
		$essence			=	new Essentials();
		$db 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db11 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db2 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db3 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db4 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db5 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db6 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db7 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db8 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		$mailbox_message	=	$essence->tblPrefix().'mailbox_message';
		$mailbox_conv		=	$essence->tblPrefix().'mailbox_conversation';
		
	    $sql				=  	"SELECT * FROM `$mailbox_conv` WHERE conversation_id=$cid";
		$r					=	$db->Query($sql);
		$row				=	$db->Row();
		$initiator_id		=	$row->initiator_id;
		//echo "sender_id=".$initiator_id;
		$sqlq				=	"SELECT `bm_deleted` FROM `$mailbox_conv` WHERE conversation_id=$cid";
		$r1					=	$db11->Query($sqlq);
		$row1				=	$db11->Row();
		$bm					=	$row1->bm_deleted;
		//echo "bm_read=".$bm;
		switch($bm)
		{
			case 0:
					if($pid!=$initiator_id)
					{
						$sql1 =	"UPDATE `$mailbox_conv` SET `bm_deleted`=2 WHERE `conversation_id`=$cid";
						$db1->Query($sql1);
						
					}
					else
					{
						$sql2 =	"UPDATE `$mailbox_conv` SET `bm_deleted`=1 WHERE `conversation_id`=$cid";
						$db2->Query($sql2);
						
					}
					break;
			case 1: 
					if($pid!=$initiator_id)
					{
						$sql3 =	"DELETE FROM `$mailbox_conv` where `conversation_id`=$cid";
						$db3->Query($sql3);
						$sql4 =	"DELETE FROM `$mailbox_message` where `conversation_id`=$cid";
						$db4->Query($sql4);
						
					}
					break;
			case 2: 
					if($pid=$initiator_id)
					{
						$sql5 =	"DELETE FROM `$mailbox_conv` where `conversation_id`=$cid";
						$db5->Query($sql5);
					    $sql6 =	"DELETE FROM `$mailbox_message` where `conversation_id`=$cid";
						$db6->Query($sql6);
						
					}
					break;
			case 3: 
					$sql7	=	"DELETE FROM `$mailbox_conv` where `conversation_id`=$cid";
					$db7->Query($sql7);
					$sql8 	=	"DELETE FROM `$mailbox_message` where `conversation_id`=$cid";
					$db8->Query($sql8);
		}
				
		if($db->Query($sql))
		{
			echo '{"Message":"Success"}';
		}
		else
		{
			echo '{"Message":"Error"}';
		}
	}
	
	/** ------------------------------------------------------------------ */
	public function DeleteConversation($id)
	{	
		$essence			=	new Essentials();
		$mailboxconv		=	$essence->tblPrefix().'mailbox_conversation';
		$sql				=	"DELETE FROM `$mailboxconv` WHERE conversation_id=$id";
		$db 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		if($db->Query($sql))
		{
			echo '{"Message":"Success"}';
		}
		else
		{
			echo '{"Message":"Error"}';
		}
	}
	/** ------------------------------------------------------------------ */
	public function DeleteMessage($id)
	{	
		$essence			=	new Essentials();
		$profile_pic_tbl	=	$essence->tblPrefix().'mailbox_message';
		$sql				=	"DELETE FROM `$profile_pic_tbl` WHERE message_id=$id";
		$db 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		if($db->Query($sql))
		{
			echo '{"Message":"Success"}';
		}
		else
		{
			echo '{"Message":"Error"}';
		}
	}
	/** ------------------------------------------------------------------ */
	public function DeleteMessageBySender($sid,$rid,$cid)
	{	
		$essence				=	new Essentials();
		$mailbox_message		=	$essence->tblPrefix().'mailbox_message';
		$mailbox_message_tbl	=	$essence->tblPrefix().'mailbox_conversation';
		$db 					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1 					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db2					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		$query = "SELECT `bm_deleted` FROM `$mailbox_message_tbl` WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
		
		$bm_deleted=mysql_query($query);
		$row=mysql_fetch_array($bm_deleted);
		$bm_del=$row['bm_deleted'];
		//echo $bm_del;
		if($bm_del>0)
		{
		  // $sql =	"UPDATE `$mailbox_message_tbl` SET `bm_deleted`=2 WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
		     $sql 	=	"DELETE FROM `$mailbox_message_tbl` WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
			 $del  =	"DELETE FROM `$mailbox_message` WHERE `conversation_id`=$cid";
			 $db2->Query($del);
		   if($db->Query($sql))
			{
				echo '{"Message":"Success"}';
			}
			else
			{
				echo '{"Message":"Error"}';
			}
		}
		else
		{			
			$sql1 =	"UPDATE `$mailbox_message_tbl` SET `bm_deleted`=1 WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
			if($db1->Query($sql1))
			{
				echo '{"Message":"Success"}';
			}
			else
			{
				echo '{"Message":"Error"}';
			}
		}
	}
	/** ------------------------------------------------------------------ */
	public function DeleteMessageByRecipient($sid,$rid,$cid)
	{	
		$essence				=	new Essentials();
		$mailbox_message		=	$essence->tblPrefix().'mailbox_message';
		$mailbox_message_tbl	=	$essence->tblPrefix().'mailbox_conversation';
		$db 					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db2					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		$query = "SELECT `bm_deleted` FROM `$mailbox_message_tbl` WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
		
		$bm_deleted=mysql_query($query);
		$row=mysql_fetch_array($bm_deleted);
		$bm_del=$row['bm_deleted'];
		//echo $bm_del;
		if($bm_del>0)
		{
		  // $sql =	"UPDATE `$mailbox_message_tbl` SET `bm_deleted`=2 WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
		     $sql  ="DELETE FROM `$mailbox_message_tbl` WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
			 $del  ="DELETE FROM `$mailbox_message` WHERE `conversation_id`=$cid";
			 $db2->Query($del);
		   if($db->Query($sql))
			{
				echo '{"Message":"Success"}';
			}
			else
			{
				echo '{"Message":"Error"}';
			}
		}
		else
		{			
			$sql1 =	"UPDATE `$mailbox_message_tbl` SET `bm_deleted`=2 WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
			if($db1->Query($sql1))
			{
				echo '{"Message":"Success"}';
			}
			else
			{
				echo '{"Message":"Error"}';
			}
		}
		
	}
	/** ------------------------------------------------------------------ */
	public function ReplyMessage($mid,$msg)
	{	
		$essence				=	new Essentials();
		$mailbox_message_tbl	=	$essence->tblPrefix().'mailbox_message';
		$profile_table_extend	=	$essence->tblPrefix().'mailbox_conversation';
		$db						= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db2					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db3					= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		
		$sql1					=   "SELECT * from `$mailbox_message_tbl` where `message_id`= $mid";
		if($db->Query($sql1))
		{
			$row1		=	$db->Row();
			$cid		=	$row1->conversation_id;
			$time		=	time();
			$sender		=	$row1->sender_id;
			$recipient	=	$row1->recipient_id;
			//echo $sender;
			
			$sql2		=   "SELECT * from `$profile_table_extend` where `conversation_id`= $cid";
			if($db2->Query($sql2))
			{
				$row2			=	$db2->Row();
				$initiator		=	$row2->initiator_id;
				$bm_deleted		=	$row2->bm_deleted;
				//$interlocutor	=	$row2->interlocutor_id;
				//echo $initiator;
				
					$sql		=	"INSERT into `$mailbox_message_tbl` values('', '$cid', '$time', '$recipient', '$sender', '$msg', 'no', 'yes', 'a', '')";
					if($db->Query($sql))
					{
					    if($initiator != $sender)
						{
							$sql1 =	"UPDATE `$profile_table_extend` SET `bm_read`=1,`bm_deleted`=0 WHERE  `initiator_id`=$recipient AND `interlocutor_id`=$sender AND `conversation_id`=$cid";
							$db1->Query($sql1);
						}
						else
						{
						    $sql3 =	"UPDATE `$profile_table_extend` SET `bm_read`=2,`bm_deleted`=0 WHERE `initiator_id`=$sender AND `interlocutor_id`=$recipient AND `conversation_id`=$cid";
							$db3->Query($sql3);
						}
						echo '{"Message":"Success"}';
					}
					else
					{
						echo '{"Message":"Error"}';
					}
			}	
		}
	}
	/** ------------------------------------------------------------------ */
	public function ViewInbox($id)
	{	
		$essence			=	new Essentials();
		$profile_table		=	$essence->tblPrefix().'profile';
		$db 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$mail_conv_tbl		=	$essence->tblPrefix().'mailbox_conversation';
		$mail_msg_tbl		=	$essence->tblPrefix().'mailbox_message';
		$pic_tbl			=	$essence->tblPrefix().'profile_photo';
		
		/*echo   $sql="SELECT * FROM (SELECT * FROM (SELECT `m`.`message_id`, COUNT(`m`.`message_id`) AS `MailCount`,COUNT(`m`.`conversation_id`) AS `conversation_number`, `m`.`sender_id`, `m`.`recipient_id`, `m`.`is_kiss`, `m`.`text`, `m`.`is_readable`, `m`.`time_stamp` AS `last_message_ts`, FROM_UNIXTIME(`m`.`time_stamp`, '%T' ) AS Time, `c`.`conversation_id` as conv_id, `c`.*, `ms`.`is_replied` FROM `skadate_mailbox_conversation` AS `c` INNER JOIN ( SELECT * FROM `skadate_mailbox_message` WHERE `recipient_id`=$id AND IF (`sender_id`!=$id, `status`='a', 1) ORDER BY `time_stamp` DESC ) AS `m` ON(`m`.`conversation_id`=`c`.`conversation_id`) INNER JOIN ( SELECT `conversation_id`, IF(`sender_id`=$id,'yes','no') AS `is_replied` FROM `skadate_mailbox_message` WHERE (`recipient_id`=$id OR `sender_id`=$id) ORDER BY `time_stamp` DESC ) AS `ms` ON(`ms`.`conversation_id`=`c`.`conversation_id`) WHERE (`c`.`initiator_id`=$id OR `interlocutor_id`=$id) AND `c`.`bm_deleted` NOT IN (IF (`c`.`initiator_id`=$id, '1, 3','2, 3')) AND IF (`sender_id`!=$id, `status`='a', 1) GROUP BY `c`.`conversation_id` ORDER BY MAX( `m`.`time_stamp` ) DESC LIMIT 0,15)as M

LEFT JOIN 

(SELECT skadate_profile.profile_id, skadate_profile.username, skadate_profile.birthdate, year( CURRENT_TIMESTAMP ) - year( skadate_profile.birthdate ) AS DOB, skadate_profile.sex FROM  skadate_profile) as N ON M.`sender_id`=N.profile_id ) AS K 

LEFT JOIN 

(SELECT skadate_profile_photo.profile_id as prof_id,skadate_profile_photo.photo_id,skadate_profile_photo.index,skadate_profile_photo.number, CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic FROM skadate_profile_photo WHERE skadate_profile_photo.number =0 )AS L

ON K.profile_id=L.prof_id";
*/


$sql="SELECT * FROM (SELECT * FROM (SELECT * FROM (SELECT `m`.`message_id`, COUNT(`m`.`message_id`) AS `MailCount`,COUNT(`m`.`conversation_id`) AS `conversation_number`, `m`.`sender_id`, `m`.`recipient_id`, `m`.`is_kiss`, `m`.`text`, `m`.`is_readable`, `m`.`time_stamp` AS `last_message_ts`, FROM_UNIXTIME(`m`.`time_stamp`, '%T' ) AS Time, `c`.`conversation_id` as conv_id, `c`.*, `ms`.`is_replied` FROM `skadate_mailbox_conversation` AS `c` INNER JOIN ( SELECT * FROM `skadate_mailbox_message` WHERE `recipient_id`=$id AND IF (`sender_id`!=$id, `status`='a', 1) ORDER BY `time_stamp` DESC ) AS `m` ON(`m`.`conversation_id`=`c`.`conversation_id`) INNER JOIN ( SELECT `conversation_id`, IF(`sender_id`=$id,'yes','no') AS `is_replied` FROM `skadate_mailbox_message` WHERE (`recipient_id`=$id OR `sender_id`=$id) ORDER BY `time_stamp` DESC ) AS `ms` ON(`ms`.`conversation_id`=`c`.`conversation_id`) WHERE (`c`.`initiator_id`=$id OR `interlocutor_id`=$id) AND `c`.`bm_deleted` NOT IN (IF (`c`.`initiator_id`=$id, '1, 3','2, 3')) AND IF (`sender_id`!=$id, `status`='a', 1) GROUP BY `c`.`conversation_id` ORDER BY MAX( `m`.`time_stamp` ) DESC LIMIT 0,15)as M LEFT JOIN (SELECT skadate_profile.profile_id, skadate_profile.username, skadate_profile.birthdate, year( CURRENT_TIMESTAMP ) - year( skadate_profile.birthdate ) AS DOB, skadate_profile.sex FROM skadate_profile) as N ON M.`sender_id`=N.profile_id ) AS K LEFT JOIN (SELECT skadate_profile_photo.profile_id as prof_id,skadate_profile_photo.photo_id,skadate_profile_photo.index,skadate_profile_photo.number, CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic FROM skadate_profile_photo WHERE skadate_profile_photo.number =0 )AS L ON K.profile_id=L.prof_id) as TAB1

LEFT JOIN

(select count( conversation_id ) as conversation_number, conversation_id from `skadate_mailbox_message` where recipient_id = $id or sender_id =$id group by conversation_id )as TAB2
ON
		TAB1.conversation_id=TAB2.conversation_id";
			
		
	/*$db1->Query($sql1);
	$row		 =	$db1->Row();
     $conv_count =	$row->conv_count;*/
	
			if($db->Query($sql))
			{
				if($db->RowCount())
				{	
					//$url		=	$this->getThumbImage($id);
					//if($url	==	"")
						//$url	=	"NULL";
					$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
					$profile	=	str_replace('},]}','}]}',$profile);
					echo $profile;
				}
				else
				{
					echo '{"count":"0","Message":"Incorrect ID"}';
				}	
			}
	}
	/** ------------------------------------------------------------------ */

	

	/** ------------------------------------------------------------------ */
	public function SendMail($id)
	{	
		$essence			=	new Essentials();
		$profile_table		=	$essence->tblPrefix().'profile';
		$db 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$mail_conv_tbl		=	$essence->tblPrefix().'mailbox_conversation';
		$mail_msg_tbl		=	$essence->tblPrefix().'mailbox_message';
		$profile_pic_tbl	=	$essence->tblPrefix().'profile_photo';
				
		
      /* $sql="SELECT * FROM(select message_id,conversation_id,time_stamp,sender_id,recipient_id,text,subject,profile_id,username,sex,Time,conversation_number from 
(SELECT skadate_mailbox_message.message_id,skadate_mailbox_message.conversation_id,skadate_mailbox_message.time_stamp,skadate_mailbox_message.sender_id, skadate_mailbox_message.recipient_id,skadate_mailbox_message.text,skadate_mailbox_message.is_kiss,skadate_mailbox_message.is_readable,skadate_mailbox_message.status, skadate_mailbox_message.hash,skadate_mailbox_conversation.initiator_id,skadate_mailbox_conversation.interlocutor_id,skadate_mailbox_conversation.subject, skadate_mailbox_conversation.bm_read,skadate_mailbox_conversation.bm_deleted,skadate_mailbox_conversation.bm_read_special,skadate_mailbox_conversation.conversation_ts, skadate_mailbox_conversation.is_system, skadate_profile.profile_id,skadate_profile.email, skadate_profile.username, skadate_profile.password, skadate_profile.sex, skadate_profile.match_sex, skadate_profile.birthdate, skadate_profile.headline, skadate_profile.general_description, skadate_profile.match_agerange, skadate_profile.custom_location, skadate_profile.country_id, skadate_profile.zip, skadate_profile.state_id, skadate_profile.city_id, skadate_profile.join_stamp, skadate_profile.activity_stamp, skadate_profile.membership_type_id, skadate_profile.affiliate_id, skadate_profile.email_verified,skadate_profile.reviewed, skadate_profile.has_photo, skadate_profile.has_media, skadate_profile.featured, skadate_profile.register_invite_score,skadate_profile.rate_score,skadate_profile.rates,skadate_profile.language_id,skadate_profile.join_ip, skadate_profile.neigh_location, skadate_profile.neigh_location_distance, skadate_profile.bg_color, skadate_profile.bg_image, skadate_profile.bg_image_url, skadate_profile.bg_image_mode, skadate_profile.bg_image_status, skadate_profile.has_music, skadate_profile.is_private,
 FROM_UNIXTIME(time_stamp, '%T' ) AS Time 
FROM `skadate_mailbox_conversation` , `skadate_mailbox_message` , `skadate_profile`

 WHERE
 `skadate_mailbox_message`.sender_id =$id AND `skadate_mailbox_conversation`.bm_deleted !=1 AND `skadate_mailbox_message`.conversation_id = `skadate_mailbox_conversation`.conversation_id AND `skadate_profile`.profile_id =`skadate_mailbox_message`.recipient_id)X, 

 (select count( conversation_id ) as conversation_numberr,'0' as conversation_number,conversation_id as conversation_i from skadate_mailbox_message where recipient_id = $id or sender_id = $id group by conversation_i )Y 

where X.conversation_id=Y. conversation_i ) as A 

LEFT JOIN

(select *,CONCAT( '/$','userfiles/thumb_', CAST( pictable .profile_id AS CHAR ) , '_',CAST( pictable .photo_id AS CHAR ) , '_',CAST( pictable .index AS CHAR ) , '.jpg' ) as Profile_Pic 
FROM `skadate_profile_photo` as pictable where `number` = 0) as  B

ON

A.profile_id = B.profile_id  ORDER BY time_stamp DESC";*/


$sql="SELECT * FROM(SELECT * FROM(SELECT `m`.`message_id`, COUNT(`m`.`message_id`) AS `MailCount`,COUNT(`m`.`conversation_id`) AS `conversation_number`, `m`.`sender_id`, `m`.`recipient_id`, `m`.`is_kiss`, `m`.`text`, `m`.`is_readable`, FROM_UNIXTIME(`m`.`time_stamp`, '%T' ) AS `Time`, `c`.`conversation_id` as conv_id, `c`.*, `ms`.`is_replied` FROM `skadate_mailbox_conversation` AS `c` INNER JOIN ( SELECT * FROM `skadate_mailbox_message` WHERE `sender_id`=$id AND IF (`sender_id`!=$id, `status`='a', 1) ORDER BY `time_stamp` DESC ) AS `m` ON(`m`.`conversation_id`=`c`.`conversation_id`) INNER JOIN ( SELECT `conversation_id`, IF(`sender_id`=$id,'yes','no') AS `is_replied` FROM `skadate_mailbox_message` WHERE (`recipient_id`=$id OR `sender_id`=$id) ORDER BY `time_stamp` DESC ) AS `ms` ON(`ms`.`conversation_id`=`c`.`conversation_id`) WHERE (`c`.`initiator_id`=$id OR `interlocutor_id`=$id) AND `c`.`bm_deleted` NOT IN (IF (`c`.`initiator_id`=$id, '1, 3','2, 3')) AND IF (`sender_id`!=$id, `status`='a', 1) GROUP BY `c`.`conversation_id` ORDER BY MAX( `m`.`time_stamp` ) DESC LIMIT 0,15) as P

JOIN

(SELECT skadate_profile.profile_id, skadate_profile.username, skadate_profile.birthdate, year(
CURRENT_TIMESTAMP ) - year( skadate_profile.birthdate ) AS DOB, skadate_profile.sex
FROM skadate_profile) AS Q ON P.recipient_id=Q.profile_id) AS A

LEFT JOIN

(SELECT skadate_profile_photo.profile_id as prof_id,skadate_profile_photo.photo_id,skadate_profile_photo.index,skadate_profile_photo.number, CONCAT( '/$', 'userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_', CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) AS Profile_Pic FROM skadate_profile_photo  WHERE skadate_profile_photo.number =0 )AS B

 ON A.profile_id=B.prof_id";
	if($db->Query($sql))
			{
				if($db->RowCount())
				{	
					$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
					echo $profile = str_replace("},]", "}]", $profile);
				}
				else
				{
					echo '{"count":"0","Message":"Incorrect ID"}';
				}	
			}
	}
	 /** ------------------------------------------------------------------ */
		public function ConversationDetails($id)
		{	
		$essence			=	new Essentials();
		$profile_table		=	$essence->tblPrefix().'profile';
		$pic_tbl			=	$essence->tblPrefix().'profile_photo';
		$db 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$db1				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$mail_conv_tbl		=	$essence->tblPrefix().'mailbox_conversation';
		$mail_msg_tbl		=	$essence->tblPrefix().'mailbox_message';
				
		 $sql				=		"select *,CONCAT( '/$','userfiles/thumb_', CAST( pictable .profile_id AS CHAR ) , '_',
									CAST( pictable .photo_id AS CHAR ) , '_', CAST( pictable .index AS CHAR ) , '.jpg' ) as Profile_Pic,
									FROM_UNIXTIME(time_stamp,'%T') as Time from `$mail_msg_tbl`
									JOIN `$mail_conv_tbl` ON (`$mail_msg_tbl`.conversation_id =$id AND `$mail_conv_tbl`.conversation_id=$id)
									LEFT JOIN `$pic_tbl` as pictable ON (`$mail_msg_tbl`.`sender_id` = `pictable`.`profile_id` AND `pictable`.`number`=0) 
									LEFT JOIN `$profile_table` ON (`$mail_msg_tbl`.sender_id=`$profile_table`.profile_id)";
			
		if($db->Query($sql))
			{
				if($db->RowCount())
				{	
					
					$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
					$profile	=	str_replace('},]}','}]}',$profile);
					echo $profile;
					$sql1 =	"UPDATE `$mail_conv_tbl` SET `bm_read`=3 ,`bm_read_special`=3 WHERE `conversation_id`=$id";
				    $db1->Query($sql1);
				}
				else
				{
					echo '{"count":"0","Message":"Incorrect ID"}';
				}	
			}
		}
		public function ConversationDetailsTemp($id)
		{	
		$essence			=	new Essentials();
		$profile_table		=	$essence->tblPrefix().'profile';
		$pic_tbl			=	$essence->tblPrefix().'profile_photo';
		$db 				= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		$mail_conv_tbl		=	$essence->tblPrefix().'mailbox_conversation';
		$mail_msg_tbl		=	$essence->tblPrefix().'mailbox_message';
				
		echo $sql				=		"select *,CONCAT( '/$','userfiles/thumb_', CAST( pictable .profile_id AS CHAR ) , '_',
CAST( pictable .photo_id AS CHAR ) , '_',
CAST( pictable .index AS CHAR ) , '.jpg' ) as Profile_Pic,FROM_UNIXTIME(time_stamp,'%T') as Time from `$mail_msg_tbl`
 JOIN `$mail_conv_tbl` ON (`$mail_msg_tbl`.conversation_id =$id AND `$mail_conv_tbl`.conversation_id=$id)
 LEFT JOIN `$pic_tbl` as pictable ON (`$mail_msg_tbl`.`recipient_id` = `pictable`.`profile_id` AND `pictable`.`number`=0) 
LEFT JOIN `$profile_table` ON (`$mail_msg_tbl`.recipient_id=`$profile_table`.profile_id)";
			
		if($db->Query($sql))
			{
				if($db->RowCount())
				{	
					$url		=	$this->getThumbImage($id);
					if($url	==	"")
						$url	=	"NULL";
					$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
					$profile	=	str_replace('},]}','}]}',$profile);
					echo $profile;
				}
				else
				{
					echo '{"count":"0","Message":"Incorrect ID"}';
				}	
			}
		}
	
	/** ------------------------------------------------------------------ */
	 	public function getMessageDetails($id)
		{
			$essence = new Essentials();
			$db = new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			$db1 = new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			
			$profile_table = $essence->tblPrefix().'profile';
			$mail_conv_tbl = $essence->tblPrefix().'mailbox_conversation';
			$mail_msg_tbl = $essence->tblPrefix().'mailbox_message';
				
			if (!$db->Error())
			{
				//$mail_conv_tbl = $essence->tblPrefix().'mailbox_conversation';
				//$mail_msg_tbl = $essence->tblPrefix().'mailbox_message';
				/*echo $sql1 = " SELECT *,FROM_UNIXTIME(time_stamp,'%d %b %Y %T:%f') as DateTime FROM `$mail_msg_tbl`,`$mail_conv_tbl`
				WHERE `$mail_msg_tbl`.message_id =$id AND `$mail_msg_tbl`.sender_id =`$mail_conv_tbl`.initiator_id AND `$mail_msg_tbl`.recipient_id=`$mail_conv_tbl`.interlocutor_id AND `$mail_msg_tbl`.conversation_id =`$mail_conv_tbl`.conversation_id";*/
				
				 $sql = "SELECT *,FROM_UNIXTIME(time_stamp,'%d %b %Y %T:%f') as DateTime FROM `skadate_mailbox_message`,`skadate_mailbox_conversation` 
                 WHERE `skadate_mailbox_message`.message_id =$id AND  `skadate_mailbox_message`.conversation_id =`skadate_mailbox_conversation`.conversation_id";
                 $result=mysql_query($sql);
				 $rslt=mysql_fetch_array($result);
				 $mid=$rslt['message_id'];
				 $cid=$rslt['conversation_id'];
				 $sid=$rslt['sender_id'];
				 $rid=$rslt['recipient_id'];
				
				$qry="select recipient_id from `$mail_msg_tbl` where `$mail_msg_tbl`.message_id=$id";
				$pi=mysql_query($qry);
				
				$row=mysql_fetch_array($pi);
				$pid=$row['recipient_id'];
				//echo "pid=".$pid;
				
				$rst=mysql_query("select username, sex from `$profile_table` where profile_id=$pid");
				$row1=mysql_fetch_array($rst);
				$uname=$row1['username'];
				$sex=$row1['sex'];
				
	
				if ($db->Query($sql))
				{
					if($db->RowCount())
					{
						$url = $this->getThumbImage($pid);
						if($url == "")
						$url = "NULL";
						$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
						$profile = str_replace('},]}',',"username":"'.$uname.'","sex":"'.$sex.'","Profile_Image":"'.$url.'"}',$profile);
						$profile = str_replace("}", "}]}", $profile);
						echo $profile;
						
						/////////////
						//"SELECT COUNT(conversation_id) AS cnt FROM $mailbox_conversation_tbl where interlocutor_id=$pid AND bm_read=1";
						 $sql1 =	"UPDATE `$mail_conv_tbl` SET `bm_read`=3 ,`bm_read_special`=3 WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
					     $db1->Query($sql1);
						/////////////	
					}
					else
					{
						echo '{"Message":"Incorrect ID"}';
					}
				
				}
			}
			else
			{
				echo '{"Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
		}
		/** ------------------------------------------------------------------ */
		public function getMessageDetailsInverse($id)
		{
			$essence = new Essentials();
			$db = new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			$db1 = new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
			$profile_table = $essence->tblPrefix().'profile';
			if (!$db->Error())
			{
				$mail_conv_tbl = $essence->tblPrefix().'mailbox_conversation';
				$mail_msg_tbl = $essence->tblPrefix().'mailbox_message';
				
				/*$sql = " SELECT *,FROM_UNIXTIME(time_stamp,'%d %b %Y %T:%f') as DateTime FROM `$mail_msg_tbl`,`$mail_conv_tbl`
				WHERE `$mail_msg_tbl`.message_id =$id AND `$mail_msg_tbl`.sender_id =`$mail_conv_tbl`.initiator_id AND `$mail_msg_tbl`.recipient_id=`$mail_conv_tbl`.interlocutor_id AND `$mail_msg_tbl`.conversation_id =`$mail_conv_tbl`.conversation_id";*/
				
				$sql = "SELECT *,FROM_UNIXTIME(time_stamp,'%d %b %Y %T:%f') as DateTime FROM `skadate_mailbox_message`,`skadate_mailbox_conversation` 
                 WHERE `skadate_mailbox_message`.message_id =$id AND  `skadate_mailbox_message`.conversation_id =`skadate_mailbox_conversation`.conversation_id";
				
				 $result=mysql_query($sql);
				 $rslt=mysql_fetch_array($result);
				 $mid=$rslt['message_id'];
				 $cid=$rslt['conversation_id'];
				 $sid=$rslt['sender_id'];
				 $rid=$rslt['recipient_id'];
				 
				$pid=mysql_query("select sender_id from `$mail_msg_tbl` where `$mail_msg_tbl`.message_id=$id");
				$row=mysql_fetch_array($pid);
				$pid=$row['sender_id'];
				
															 
				$rst=mysql_query("select username, sex from `$profile_table` where profile_id=$pid");
				
				$row1=mysql_fetch_array($rst);
				$uname=$row1['username'];
				$sex=$row1['sex'];
			
				if ($db->Query($sql))
				{
					if($db->RowCount())
					{
						$url = $this->getThumbImage($pid);
						if($url == "")
						$url = "NULL";
						$profile = '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
						$profile = str_replace('},]}',',"username":"'.$uname.'","sex":"'.$sex.'","Profile_Image":"'.$url.'"}',$profile);
						$profile = str_replace("}", "}]}", $profile);
						echo $profile;
						
						$sql1 =	"UPDATE `$mail_conv_tbl` SET `bm_read`=3 ,`bm_read_special`=3 WHERE `interlocutor_id`=$rid AND `initiator_id`=$sid AND `conversation_id`=$cid";
						$db1->Query($sql1);
					}
					else
					{
						echo '{"Message":"Incorrect ID"}';
					}
				
				}
			}
			else
			{
				echo '{"Message":"Error connecting to database. Check configuration"}';
				$db->Kill();
			}
		}

	 /** ------------------------------------------------------------------ */
	public function getMyWatches($id)
	{	
				
		$essence			 =  new Essentials();
		$profile			 =  $essence->tblPrefix().'profile';
		$profile_view		 =	$essence->tblPrefix().'profile_view_history';
		$profile_pic_tbl	 =	$essence->tblPrefix().'profile_photo';
		
		$db = new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
      /*$sql1 = "SELECT *, year(CURRENT_TIMESTAMP ) - year( birthdate ) AS DOB,CONCAT( '/$','userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_',
CAST( skadate_profile_photo.photo_id AS CHAR ) , '_',
CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) as Profile_Pic
						FROM skadate_profile
						JOIN skadate_profile_view_history ON ( skadate_profile.`profile_id` = skadate_profile_view_history.`profile_id` 
						AND skadate_profile_view_history.`profile_id` =$id ) 
						JOIN skadate_profile_photo ON ( skadate_profile.`profile_id` = skadate_profile_photo.`profile_id` 
						AND skadate_profile_photo.number =0)";*/
						
		
  $sql1 ="SELECT * FROM (SELECT * FROM (SELECT `p`.*,year(CURRENT_TIMESTAMP ) - year(`p`.`birthdate`) AS DOB, `pvh`.`view_count`, `pvh`.`view_time`, `pvh`.`time_stamp` FROM `skadate_profile` AS `p` 

RIGHT JOIN (SELECT `profile_id`, COUNT(`profile_id`) AS `view_count`,`time_stamp`, MAX(time_stamp) view_time FROM `skadate_profile_view_history` WHERE `viewed_id`=$id GROUP BY `profile_id`) AS `pvh` USING(`profile_id`) 

ORDER BY `pvh`.`time_stamp` DESC) as A LEFT JOIN (SELECT profile_id as prof_id,CONCAT( '/$','userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , '_', CAST( skadate_profile_photo.photo_id AS CHAR ) , '_',CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) as Profile_Pic FROM skadate_profile_photo where skadate_profile_photo.number =0) as B ON A.profile_id=B.prof_id) AS TAB1

LEFT JOIN

(SELECT * FROM `skadate_location_country`) AS TAB2 ON TAB1.country_id=TAB2.Country_str_code";
						
		if($db->Query($sql1))
		{	
			if($db->RowCount())
			{	
				$stri	=	 '{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
				echo str_replace("},]","}]",$stri);
			}
			else
			{
				echo '{"count": 0,"result": ['.$db->GetJSON().']}';
			
			}
		}
		
	}
		
	 /** ------------------------------------------------------------------ */
	public function ImageUpload($id)
	{
		$essence = new Essentials();
		$profile_pic = $essence->tblPrefix().'profile_photo';
		$db = new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
        $sql = "SELECT max(`number`) as number from $profile_pic where `profile_id`=$id";
		if($db->Query($sql))
		{
			$row = $db->Row();
			$index = rand(1,99);
			$number = $row->number?$row->number+1:1;
			$time = time();
			$keyvalue = array('photo_id'=>'NULL', 'profile_id'=>$id, 'index'=>$index, 'status'=>'"active"', 'number'=>$number, 'description'=>'NULL', 'publishing_status'=>'"public"', 'password'=>'NULL', 'title'=>'NULL', 'added_stamp'=>$time, 'authed'=>0);
           

            
            //$sqlins = "INSERT INTO '$profile_pic' values (NULL,$id,$index,'approval',$number,NULL,'public', NULL, NULL, $time, 0)";
			$photo_id	=	$db->InsertRow($profile_pic,$keyvalue);

            //if($db->Query($sqlins))
			//{
               // $row    =   $db->Row();
				$result = array('photoid'=>$photo_id, 'index'=>$index, 'profile_id'=>$id);
                ///print_r($result);
				return $result;
			//}
		}
	
	}
}

?>