<?php
class search
{
	public function sSearch($kv)
	{
	    /*	
		 	Search Members MS2
			Input given
			Gender, LookingFor, AgeRangeFrom, AgeRangeTo, MilesFrom, ZIP, OnlineOnly, WithPhotoOnly
			Output Desired
			List of profiles each with DisplayName, Gender, Age, Place, OnlineStatus
		*/
		//print_r($kv);
		$this->actualSearch($kv);
	}
	private function actualSearch($kv)
	{
		$profileId		=	isset($kv["id"])?$kv["id"]:NULL;
		$sex			=	isset($kv["sex"])?$kv["sex"]:NULL;
		$matchSex		=	isset($kv["matchSex"])?$kv["matchSex"]:NULL;
		$ageRangeFrom	=	isset($kv["ageRangeFrom"])?$kv["ageRangeFrom"]:NULL;
		$ageRandeTo		=	isset($kv["ageRangeTo"])?$kv["ageRangeTo"]:NULL;
		$milesFrom		=	isset($kv["milesFrom"])?$kv["milesFrom"]:NULL;
		$zip			=	isset($kv["zip"])?$kv["zip"]:NULL;
		$onlineOnly		=	isset($kv["onlineOnly"])?$kv["onlineOnly"]:'n';
		$withPhotoOnly	=	isset($kv["withPhotoOnly"])?$kv["withPhotoOnly"]:'n';
		
		$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		if (!$db->Error())
			{
				$profile_tbl			=	$essence->tblPrefix().'profile';
				$profile_tbl_extended	=	$essence->tblPrefix().'profile_extended';
				$profile_tbl_online		=	$essence->tblPrefix().'profile_online';
				$location_tbl			=	$essence->tblPrefix().'location_zip';
				$country_tbl			=	$essence->tblPrefix().'location_country';
				if($zip)
				{
					$latlongsql		=	"SELECT `latitude` AS `lat`, `longitude` AS `lon` FROM `".$location_tbl."` WHERE `zip`='$zip'";
					
					if ($db->Query($latlongsql))
					{
						if($db->RowCount())
						{	
							$row			=	$db->Row();
							//print_r($row);
							$lat			=	$row->lat;
							$long			=	$row->lon;
						}
					}
				}
				$searchquery	=	"SELECT * FROM	(SELECT *,hash as OnlineStatus, year(CURRENT_TIMESTAMP)-year(birthdate) as DOB FROM `$profile_tbl` AS `main` 
										LEFT JOIN `$profile_tbl_extended` AS `extend` USING( `profile_id` ) 
										LEFT JOIN `$profile_tbl_online` AS `online` USING( `profile_id` )
										LEFT JOIN `$country_tbl` AS `ctbl` ON (main.`country_id`= ctbl.`Country_str_code`)
										";
							if($zip and $milesFrom)
							{
								 $searchquery	.= " INNER JOIN 
										( SELECT `zip` FROM `$location_tbl` 
										WHERE 
										 ( 3963.0*acos
										 ( sin( ".($lat/57.29577951).") * sin(`latitude`/57.29577951) 
										 + cos(".($lat/57.29577951).") * cos(`latitude`/57.29577951)
										 * cos(`longitude`/57.29577951 --".($long/57.29577951).") ) )
										 <= '$milesFrom' )
										 AS `zip_third` ON ( `zip_third`.`zip` = `main`.`zip` )";
							} 
							if($withPhotoOnly == 'y')
							{
									 $searchquery	.=		 	" WHERE ( `has_photo`='$withPhotoOnly' )";
							}
							else if($withPhotoOnly == 'n')
							{
									 $searchquery	.=		 	" WHERE ( `has_photo`='y'  OR `has_photo`='n')";
							}
							if($onlineOnly == 'y')
							{
									$searchquery	.=			 " AND ( `online`.`hash` IS NOT NULL )";
							}
							if($matchSex)
							{
									$searchquery	.=			 " AND $matchSex&`main`.`sex`";
							}
							if($ageRandeTo and $ageRangeFrom)
							{
									$searchquery	.=		 " AND YEAR(NOW())-YEAR(`main`.`birthdate`)- IF( DAYOFYEAR(`main`.`birthdate`) > DAYOFYEAR(NOW()),1,0) >= $ageRangeFrom 
										 AND YEAR(NOW())-YEAR(`main`.`birthdate`)-IF( DAYOFYEAR(`main`.`birthdate`) > DAYOFYEAR(NOW()),1,0) <=$ageRandeTo";
							}
									$searchquery	.=		 " AND ( `main`.`status`='active' ) AND `main`.`profile_id`!=$profileId ORDER BY `main`.`has_photo` 
										 DESC, IF( `online`.`profile_id` <> NULL, 0 , 1 ), `activity_stamp` DESC LIMIT 500)X
										 
										 LEFT JOIN 
( select photo_id,`skadate_profile_photo`.`profile_id` as profid, `index`, status, `number`, `description`,CONCAT( '/$','userfiles/thumb_', CAST( skadate_profile_photo.profile_id AS CHAR ) , 
'_',CAST( skadate_profile_photo.photo_id AS CHAR ) , '_',
CAST( skadate_profile_photo.index AS CHAR ) , '.jpg' ) as Profile_Pic from
`skadate_profile_photo`)Y 
ON X.`profile_id` = Y.`profid` AND Y.`number` = 0";
										 
				//echo $searchquery;						 
				
				if ($db->Query($searchquery))
				{
					if($db->RowCount())
					{	
						$profile	=	'{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
						echo $profile		= str_replace("},]", "}]", $profile);
					}
					else
					{
						echo $profile	=	'{"count": 0, "result": [0]}';
					}
				}
			}
	}
	public function SaveSearch($id,$sname,$criterion)
	{
		$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		if (!$db->Error())
			{
				$criterion_tbl		=	$essence->tblPrefix().'search_criterion';
				$criterion_values	=	"'".json_encode($criterion)."'";
				$newkv				=	array('profile_id' => $id, 'criterion_name' => "'".$sname."'", 'criterion' => $criterion_values);
				
				$criterion_id		=	$db->InsertRow($criterion_tbl,$newkv);
				
				echo '{"Criterion":"'.$criterion_id.'"}';
			}
	}
	
	public function FetchallSearch($id)
	{
		$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		if (!$db->Error())
			{
				$criterion_tbl		=	$essence->tblPrefix().'search_criterion';
				$sql	=	"SELECT criterion_id,criterion_name from $criterion_tbl	where profile_id=$id";
				if ($db->Query($sql))
				{
					if($db->RowCount())
					{	
						$profile	=	'{"count": '.$db->RowCount().',"result": ['.$db->GetJSON().']}';
						echo str_replace(",]}","]}",$profile);
					}
					else
					{
						echo $profile	=	'{"count": 0, "result": [0]}';
					}
				}
			}
	}
	public function FetchSearch($id)
	{
		$essence	=	new Essentials();
		$db 		= 	new MySQL(true, $essence->getDbName(), $essence->getDbHost(), $essence->getDbUser(), $essence->getDbPass());
		if (!$db->Error())
			{
				$criterion_tbl		=	$essence->tblPrefix().'search_criterion';
				$sql	=	"SELECT profile_id,criterion from $criterion_tbl where criterion_id=$id";
				if ($db->Query($sql))
				{
					$row		=	$db->Row();
					$res		=	json_decode($row->criterion);
					$kv["id"]	=	$row->profile_id;
					foreach ($res as $key => $value)
					{
						$kv[$key] = $value;
					}
					$this->actualSearch($kv);
				}
			}
	}
	
	
}
?>