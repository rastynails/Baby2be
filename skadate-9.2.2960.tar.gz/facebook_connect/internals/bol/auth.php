<?php

class FBC_Auth
{
    
    public $id;
    
    /**
     * @var string
     */
    public $remoteId;

    /**
     * @var int
     */
    public $userId;

    /**
     * @var string
     */
    public $timeStamp;
}
