<?php

class FBC_Field
{
    public $id;
    
    /**
     * @var string
     */
    public $question;
    
    /**
     * @var string
     */
    public $converter;
    
    /**
     * 
     * @var string
     */
    public $fbField;
    
}
