<?php

$__CUSTOM = @$_REQUEST['custom'];

require ( '../post_display_result.php' );
