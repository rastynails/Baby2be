<?php

$__CUSTOM = ( @$_REQUEST['cm'] != '' )? @$_REQUEST['cm'] : @$_REQUEST['custom'];

require ( '../post_display_result.php' );
