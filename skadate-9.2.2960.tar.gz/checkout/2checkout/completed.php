<?php

$__CUSTOM = $_GET['custom'];

require ( '../post_display_result.php' );

