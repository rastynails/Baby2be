<?php

$__CUSTOM = trim( $_REQUEST['m_1'] );

require ( '../post_display_result.php' );
