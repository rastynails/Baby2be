<?php

$__CUSTOM = trim( $_REQUEST['custom'] );

require ( '../post_display_result.php' );
