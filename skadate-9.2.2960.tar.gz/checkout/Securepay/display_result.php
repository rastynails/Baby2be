<?php

// Success & failure payment script (for client)

$__CUSTOM = trim( $_REQUEST['custom'] );

require_once( '../post_display_result.php' );

