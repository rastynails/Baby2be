<?php

$config['timezone'] = SK_Config::section('site')->Section('official')->time_zone;