<?php

$config['driver'] = 'native';

$config['regenerate'] = 0;

$config['name'] = 'SKMSESSID';