<?php defined('SYSPATH') OR die('No direct access allowed.');

$config['default'] = array
(
	'directory'      => 'pagination',
	'style'          => 'ska',
	'uri_segment'    => 3,
	'query_string'   => '',
	'items_per_page' => 5,
	'auto_hide'      => FALSE,
);
