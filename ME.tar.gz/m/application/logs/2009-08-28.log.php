<?php defined('SYSPATH') or die('No direct script access.'); ?>

2009-08-28 14:36:31 +07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, logout, could not be found. in file X:/home/sk7e/www/m/system/core/Kohana.php on line 787
2009-08-28 15:02:54 +07:00 --- error: Uncaught PHP Error: SK_Language::text() language key "iffline" is not exists in section "mobile" in file X:/home/sk7e/www/internals/API/Language.class.php on line 176
2009-08-28 15:02:56 +07:00 --- error: Uncaught PHP Error: SK_Language::text() language key "iffline" is not exists in section "mobile" in file X:/home/sk7e/www/internals/API/Language.class.php on line 176
2009-08-28 15:15:56 +07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, about, could not be found. in file X:/home/sk7e/www/m/system/core/Kohana.php on line 787
2009-08-28 15:15:59 +07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, privacy, could not be found. in file X:/home/sk7e/www/m/system/core/Kohana.php on line 787
2009-08-28 15:29:22 +07:00 --- error: Uncaught PHP Error: Smarty error: [in X:/home/sk7e/www/m/application/views/profile.tpl line 26]: syntax error: (secure mode) 'is_owner' not allowed in if statement (Smarty_Compiler.class.php, line 1394) in file X:/home/sk7e/www/internals/Smarty/Smarty.class.php on line 1092
2009-08-28 15:47:08 +07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, profile/bookmark/biduin, could not be found. in file X:/home/sk7e/www/m/system/core/Kohana.php on line 787
2009-08-28 15:48:08 +07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, profile/bookmark/biduin, could not be found. in file X:/home/sk7e/www/m/system/core/Kohana.php on line 787
2009-08-28 15:58:41 +07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, profile/unbookmark/biduin, could not be found. in file X:/home/sk7e/www/m/system/core/Kohana.php on line 787
