<?php

define('MOBILE_SITE_DOMAIN', 'http://www.my-site.com/m/');

define('MOBILE_EDITION_VERSION', '1.0');

define('IS_MOBILE_VERSION', true);